/* Credo — site.js · ملفّ JavaScript واحد للموقع · بلا مكتبات */
(function () {
  'use strict';
  var d = document, w = window, html = d.documentElement;
  var SCRIPT = d.currentScript && d.currentScript.src;
  var reduce = !!(w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches);
  /* نصوص الواجهة بلغة الصفحة (العربية كما كانت حرفياً) · الفرنسية: h = الساعة بنظام 24 (21 h) · dec = الفاصلة العشرية · cur = العملة بعد المبلغ · الإيطالية: hm = الساعة بنظام 24 مع الدقائق (21:00) */
  var TX = {
    ar: { menuOpen: 'فتح القائمة', menuClose: 'إغلاق القائمة', copied: 'تمّ النسخ ✓', copyManual: 'انسخ الرقم يدوياً: ', am: ' صباحاً', pm: ' مساءً', date: 'ar-LB-u-nu-latn', tz: '' },
    en: { menuOpen: 'Open menu', menuClose: 'Close menu', copied: 'Copied ✓', copyManual: 'Copy the number manually: ', am: ' a.m.', pm: ' p.m.', date: 'en-US', tz: ' Beirut time' },
    fr: { menuOpen: 'Ouvrir le menu', menuClose: 'Fermer le menu', copied: 'Copié ✓', copyManual: 'Copiez le numéro manuellement : ', am: '', pm: '', date: 'fr-FR', tz: ', heure de Beyrouth', h: ' h', dec: ',', cur: ' $' },
    it: { menuOpen: 'Apri il menu', menuClose: 'Chiudi il menu', copied: 'Copiato ✓', copyManual: 'Copia il numero manualmente: ', am: '', pm: '', date: 'it-IT', tz: ', ora di Beirut', hm: ':', dec: ',', cur: ' $' }
  };
  var T = TX[(html.getAttribute('lang') || 'ar').slice(0, 2)] || TX.ar;
  function $(s, r) { return (r || d).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); }

  /* ---------- قياس GA4 بأسماء ثابتة ---------- */
  function track(name, params) {
    try { if (typeof w.gtag === 'function') w.gtag('event', name, params || {}); } catch (e) { /* لا شيء */ }
  }
  d.addEventListener('click', function (e) {
    var el = e.target.closest && e.target.closest('[data-track]');
    if (!el) return;
    var p = {};
    if (el.hasAttribute('data-amount')) p.amount = Number(el.getAttribute('data-amount'));
    if (el.href) p.link_url = el.href;
    track(el.getAttribute('data-track'), p);
  });

  /* ---------- الترويسة + شريط التقدّم ---------- */
  var header = $('.site-header'), prog = $('.progress span'), ticking = false;
  var mcta = $('.mobile-cta'), heroEl = $('.hero, .page-hero');
  function onScroll() {
    if (ticking) return;
    ticking = true;
    w.requestAnimationFrame(function () {
      ticking = false;
      var y = w.scrollY || w.pageYOffset || 0;
      if (header) header.classList.toggle('scrolled', y > 8 || html.classList.contains('menu-open'));
      if (prog) {
        var max = html.scrollHeight - w.innerHeight;
        prog.style.transform = 'scaleX(' + (max > 0 ? Math.min(1, y / max) : 0) + ')';
      }
      if (mcta) mcta.classList.toggle('show', y > (heroEl ? Math.max(220, heroEl.offsetHeight - 320) : 300));
    });
  }
  w.addEventListener('scroll', onScroll, { passive: true });
  w.addEventListener('resize', onScroll);
  onScroll();

  /* ---------- قائمة الهاتف ---------- */
  var menuBtn = $('.menu-btn'), mnav = $('#mobile-nav');
  function setMenu(open) {
    if (!menuBtn || !mnav) return;
    html.classList.toggle('menu-open', open);
    menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    menuBtn.setAttribute('aria-label', open ? T.menuClose : T.menuOpen);
    onScroll();
    if (open) { setLangMenu(false); var first = $('a', mnav); if (first) first.focus({ preventScroll: true }); }
  }
  if (menuBtn && mnav) {
    menuBtn.addEventListener('click', function () { setMenu(!html.classList.contains('menu-open')); });
    mnav.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
    d.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && html.classList.contains('menu-open')) { setMenu(false); menuBtn.focus(); }
    });
  }

  /* ---------- زرّ اللغات ---------- */
  var langBtn = $('.lang-btn');
  function setLangMenu(open) {
    if (!langBtn) return;
    html.classList.toggle('lang-open', open);
    langBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) {
      if (html.classList.contains('menu-open')) setMenu(false);
      var f = $('#lang-menu a'); if (f) f.focus({ preventScroll: true });
    }
  }
  if (langBtn) {
    langBtn.addEventListener('click', function () { setLangMenu(!html.classList.contains('lang-open')); });
    d.addEventListener('click', function (e) { if (html.classList.contains('lang-open') && !e.target.closest('.langsw')) setLangMenu(false); });
    d.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && html.classList.contains('lang-open')) { setLangMenu(false); langBtn.focus(); }
    });
  }
  /* اقتراح اللغة: الإغلاق يُحفظ */
  $$('.suggest-x').forEach(function (b) {
    b.addEventListener('click', function () {
      html.classList.remove('sg-en', 'sg-fr', 'sg-it');
      try { localStorage.setItem('credo-suggest-off', '1'); } catch (e) { /* لا شيء */ }
    });
  });

  /* ---------- اللغة: يُحفظ الاختيار ---------- */
  $$('[data-lang]').forEach(function (a) {
    a.addEventListener('click', function () {
      try { localStorage.setItem('credo-lang', a.getAttribute('data-lang')); } catch (e) { /* لا شيء */ }
    });
  });

  /* ---------- الظهور عند النزول ---------- */
  var revs = $$('.reveal');
  if ('IntersectionObserver' in w && !reduce) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.06 });
    revs.forEach(function (el) { io.observe(el); });
  } else {
    revs.forEach(function (el) { el.classList.add('in'); });
  }

  /* شريط الهاتف السفلي: يظهر بعد النزول قليلاً تحت الواجهة (داخل onScroll) */

  /* ---------- إشعار + نسخ ---------- */
  var toastEl = $('.toast'), toastT;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastT);
    toastT = setTimeout(function () { toastEl.classList.remove('show'); }, 2600);
  }
  function copyText(t) {
    if (navigator.clipboard && w.isSecureContext) return navigator.clipboard.writeText(t);
    return new Promise(function (ok, no) {
      var ta = d.createElement('textarea');
      ta.value = t; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;top:0;opacity:0';
      d.body.appendChild(ta); ta.select();
      try { if (d.execCommand('copy')) ok(); else no(); } catch (e) { no(e); }
      d.body.removeChild(ta);
    });
  }
  $$('[data-copy]').forEach(function (b) {
    var label = b.innerHTML;
    b.addEventListener('click', function () {
      var v = b.getAttribute('data-copy');
      copyText(v).then(function () {
        b.classList.add('done'); b.textContent = T.copied;
        toast(b.getAttribute('data-toast') || T.copied);
        if (b.getAttribute('data-track-copy')) track(b.getAttribute('data-track-copy'), {});
        setTimeout(function () { b.classList.remove('done'); b.innerHTML = label; }, 2600);
      }, function () { toast(T.copyManual + v); });
    });
  });

  /* ---------- التبويبات (طرق التبرّع) ---------- */
  $$('[role="tablist"]').forEach(function (list) {
    var tabs = $$('[role="tab"]', list);
    function select(t, focus) {
      tabs.forEach(function (x) {
        var on = x === t, p = d.getElementById(x.getAttribute('aria-controls'));
        x.setAttribute('aria-selected', on ? 'true' : 'false');
        x.tabIndex = on ? 0 : -1;
        if (p) p.hidden = !on;
      });
      if (focus) t.focus();
    }
    tabs.forEach(function (t, i) {
      t.addEventListener('click', function () { select(t); });
      t.addEventListener('keydown', function (e) {
        var rtl = getComputedStyle(list).direction === 'rtl', n = null;
        if (e.key === (rtl ? 'ArrowLeft' : 'ArrowRight')) n = tabs[(i + 1) % tabs.length];
        if (e.key === (rtl ? 'ArrowRight' : 'ArrowLeft')) n = tabs[(i - 1 + tabs.length) % tabs.length];
        if (e.key === 'Home') n = tabs[0];
        if (e.key === 'End') n = tabs[tabs.length - 1];
        if (n) { e.preventDefault(); select(n, true); }
      });
    });
    var want = location.hash && list.querySelector('[data-hash="' + location.hash.slice(1) + '"]');
    select(want || tabs[0]);
  });

  /* ---------- اختيار مبلغ داخل الصفحة نفسها ---------- */
  $$('a[data-amount][href^="#"]').forEach(function (a) {
    a.addEventListener('click', function () {
      var v = a.getAttribute('data-amount');
      $$('[data-chosen]').forEach(function (el) { el.textContent = T.cur ? v + T.cur : '$' + v; el.parentNode.hidden = false; });
      $$('a[data-amount]').forEach(function (x) { x.classList.toggle('sel', x === a); });
    });
  });

  /* ---------- يوتيوب: لا يُحمَّل إلّا عند الضغط ---------- */
  $$('.yt[data-list] button').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var box = btn.parentNode, f = d.createElement('iframe');
      f.src = 'https://www.youtube-nocookie.com/embed/videoseries?list=' + encodeURIComponent(box.getAttribute('data-list')) + '&autoplay=1&rel=0&playsinline=1';
      f.title = box.getAttribute('data-title') || 'YouTube';
      f.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
      f.setAttribute('allowfullscreen', '');
      f.referrerPolicy = 'strict-origin-when-cross-origin';
      box.innerHTML = '';
      box.appendChild(f);
    });
  });

  /* ---------- عدّاد الأرقام ---------- */
  function countUp(el) {
    var txt = el.textContent, m = /^(\D*)(\d+(?:[.,]\d+)?)(.*)$/.exec(txt);
    if (!m || reduce) return;
    var pre = m[1], target = parseFloat(m[2].replace(',', '.')), dec = (m[2].split(/[.,]/)[1] || '').length, post = m[3], t0 = 0, dur = 1400;
    function step(t) {
      if (!t0) t0 = t;
      var k = Math.min(1, (t - t0) / dur);
      k = 1 - Math.pow(1 - k, 3);
      el.textContent = pre + (target * k).toFixed(dec).replace('.', T.dec || '.') + post;
      if (k < 1) w.requestAnimationFrame(step); else el.textContent = txt;
    }
    w.requestAnimationFrame(step);
  }

  /* ---------- البثّ: عدّ تنازلي بتوقيت بيروت ---------- */
  var BEIRUT;
  try {
    BEIRUT = new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Beirut', hour12: false, year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' });
  } catch (e) { BEIRUT = null; }
  function tzOffset(date) { /* فرق ساعة بيروت عن UTC بالميلي ثانية (يراعي التوقيت الصيفي) */
    var p = {};
    BEIRUT.formatToParts(date).forEach(function (x) { p[x.type] = x.value; });
    return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute, +p.second) - Math.floor(date.getTime() / 1000) * 1000;
  }
  function nextShow(now, live) {
    var hm = String(live.time || '21:00').split(':'), H = +hm[0], M = +hm[1] || 0;
    var dur = (+live.duration_min || 90) * 60000;
    var off = tzOffset(new Date(now)), wall = new Date(now + off);
    for (var i = -1; i <= 8; i++) {
      var base = Date.UTC(wall.getUTCFullYear(), wall.getUTCMonth(), wall.getUTCDate() + i, H, M);
      if (live.days.indexOf(new Date(base).getUTCDay()) < 0) continue;
      var start = base - tzOffset(new Date(base - off));
      start = base - tzOffset(new Date(start));
      if (now < start + dur) return { start: start, end: start + dur };
    }
    return null;
  }
  function timeLabel(t) {
    var p = String(t).split(':'), h = +p[0], m = p[1] || '00';
    if (T.hm) return h + T.hm + m + T.tz;   /* الإيطالية: 21:00 */
    if (T.h) return h + T.h + (m === '00' ? '' : '\u00a0' + m) + T.tz;
    return (h % 12 || 12) + ':' + m + (h < 12 ? T.am : T.pm) + T.tz;
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function runCountdown(live) {
    var box = $('[data-countdown]');
    if (!box || !BEIRUT || !live || !live.days || !live.days.length) return;
    var cells = {}, nextEl = $('[data-next]', box), cur = null, fmt;
    ['d', 'h', 'm', 's'].forEach(function (k) { cells[k] = $('[data-cd="' + k + '"]', box); });
    try { fmt = new Intl.DateTimeFormat(T.date, { timeZone: 'Asia/Beirut', weekday: 'long', day: 'numeric', month: 'long' }); } catch (e) { fmt = null; }
    function tick() {
      var now = Date.now();
      if (!cur || now >= cur.end) {
        cur = nextShow(now, live);
        if (cur && nextEl && fmt) nextEl.textContent = fmt.format(new Date(cur.start)) + ' · ' + timeLabel(live.time);
      }
      if (!cur) return;
      var on = now >= cur.start && now < cur.end;
      html.classList.toggle('live-on', on);
      if (!on) {
        var s = Math.max(0, Math.floor((cur.start - now) / 1000));
        cells.d.textContent = pad(Math.floor(s / 86400));
        cells.h.textContent = pad(Math.floor(s % 86400 / 3600));
        cells.m.textContent = pad(Math.floor(s % 3600 / 60));
        cells.s.textContent = pad(s % 60);
      }
    }
    box.classList.add('ready');
    tick();
    setInterval(tick, 1000);
  }

  /* ---------- الإعدادات: config.json هو المرجع الوحيد ---------- */
  function get(o, path) {
    return String(path).split('.').reduce(function (a, k) { return a && a[k] !== undefined ? a[k] : undefined; }, o);
  }
  function applyConfig(c) {
    if (c) {
      $$('[data-cfg-href]').forEach(function (el) { var v = get(c, el.getAttribute('data-cfg-href')); if (v) el.href = v; });
      $$('[data-cfg-text]').forEach(function (el) { /* data-plus-after: الإنكليزية تكتب + بعد الرقم (118K+) والرقم نفسه من config.json */
        var v = get(c, el.getAttribute('data-cfg-text')); if (v) { v = el.hasAttribute('data-plus-after') ? String(v).replace(/^\+/, '') : v; el.textContent = T.dec ? String(v).replace(/(\d)\.(\d)/g, '$1' + T.dec + '$2') : v; } });
      $$('[data-cfg-copy]').forEach(function (el) { var v = get(c, el.getAttribute('data-cfg-copy')); if (v) el.setAttribute('data-copy', v); });
      $$('[data-cfg-list]').forEach(function (el) { var v = get(c, el.getAttribute('data-cfg-list')); if (v) el.setAttribute('data-list', v); });
      $$('a[data-amount]').forEach(function (a) { /* رابط دفع مباشر لكل مبلغ إن وُجد، وإلّا تبقى صفحة «شارك معنا» */
        var u = get(c, 'donate_links.' + a.getAttribute('data-amount'));
        if (u && /^https:\/\//.test(u)) { a.href = u; a.target = '_blank'; a.rel = 'noopener'; }
      });
      runCountdown(c.live);
    }
    $$('[data-count]').forEach(function (el) {
      if (!('IntersectionObserver' in w)) return;
      var o = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { o.disconnect(); countUp(el); } }, { threshold: 0.4 });
      o.observe(el);
    });
  }
  (function loadConfig() {
    var inline = $('#config');
    if (inline) { try { return applyConfig(JSON.parse(inline.textContent)); } catch (e) { /* يتابع */ } }
    if (!w.fetch || !SCRIPT) return applyConfig(null);
    fetch(new URL('../../config.json', SCRIPT).href, { cache: 'no-cache' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(applyConfig, function () { applyConfig(null); });
  })();

  /* ---------- السنة في التذييل ---------- */
  $$('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ---------- عارض الصور: روابط data-zoom تفتح الصورة الكبيرة في نافذة ---------- */
  (function () {
    var links = $$('a[data-zoom]');
    var dlg = d.createElement('dialog');
    if (!links.length || !dlg.showModal) return;   /* متصفّح قديم: الرابط يفتح الصورة عادياً */
    var CLOSE = { ar: 'إغلاق', en: 'Close', fr: 'Fermer', it: 'Chiudi' }[d.documentElement.lang] || 'Close';
    dlg.className = 'zoom';
    dlg.innerHTML = '<button type="button" class="zoom-x" aria-label="' + CLOSE + '">×</button>';
    d.body.appendChild(dlg);
    var img = d.createElement('img');
    $('.zoom-x', dlg).addEventListener('click', function () { dlg.close(); });
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
    dlg.addEventListener('close', function () { if (img.parentNode) dlg.removeChild(img); img.removeAttribute('src'); });
    links.forEach(function (a) {
      a.addEventListener('click', function (e) {
        e.preventDefault();
        img.src = a.getAttribute('href');
        img.alt = a.getAttribute('data-zoom');
        dlg.appendChild(img);
        dlg.showModal();
        dlg.scrollTop = 0;
      });
    });
  })();
})();
